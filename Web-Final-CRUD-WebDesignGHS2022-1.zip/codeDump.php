<?php include($_SERVER['DOCUMENT_ROOT'].'/functions.php'); 
echo '<pre>';
var_dump($rateArray);
echo '</pre>';

$uid = $_GET['uid'];

echo '<pre>';
var_dump($uid);
echo '</pre>';

$rateCount=0;
$rateSum= 0; 
$rateMean = 0;  
foreach ($rateArray as $key => $rate) {
  if ($uid == $rate['itemUID']) {
    echo $rate['itemComment'];
    $rateCount++;

    $rateSum= $rateSum+$rate['itemRate'];
    $rateMean = $rateSum / $rateCount;
  }
}
echo '<pre>';
var_dump($rateMean);
echo '</pre>';

<?php
foreach($itemsArray as $key){
      if($key['uid'] == $_GET['itemUID']){
        echo $key['category'] . '<br>';
        echo '<a href="/rateItem.php?itemUID='.$key['uid'].'">' . $key['name'] . '</a><br>';
        echo $key['description'] . '<br>';
        echo $key['creator'] . '<br>';
        echo $key['status'] . '<br>';
        echo $key['uid'] . '<br>';
        echo '<img src="' . $key['image_url'] . '" width="400px" height="400px">';
        echo '<hr>';
      }
    }

  <input name="itemRate"><br><br>
  <input type="hidden" name="pword">
  <input type="hidden" name="url">
  <input type="hidden" name="hash">
  <input type="hidden" name="userUID">
  <input type="hidden" name="itemUID">
  <input type="submit" value="Submit" name="BTN_rateItem">
</form>  
    </div>
    </div>
?>

    $_SESSION['status']['itemUID'] = $_GET['itemUID'];

    <div class="row m-2">
    <div class="col m-2">
      <h4>Rate an item!</h4><br>
<form action="https://php-always-on.toddbenrud.repl.co/webDesign/reviewCRUD/accessPoint.php?reason=rateItem" method="post">
</form>
    </div>
    </div>